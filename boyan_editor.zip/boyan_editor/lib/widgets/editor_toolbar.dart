import 'package:flutter/material.dart';

class ToolItem {
  final String label;
  final IconData icon;
  final bool enabled;
  final VoidCallback onTap;
  const ToolItem(this.label, this.icon, this.onTap, {this.enabled = false});
}

class EditorToolbar extends StatelessWidget {
  final List<ToolItem> items;
  const EditorToolbar({super.key, required this.items});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 72,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: items.length,
        itemBuilder: (context, i) {
          final it = items[i];
          return InkWell(
            onTap: it.onTap,
            child: SizedBox(
              width: 76,
              child: Opacity(
                opacity: it.enabled ? 1 : 0.4,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(it.icon),
                    const SizedBox(height: 4),
                    Text(it.label, style: const TextStyle(fontSize: 11)),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}
