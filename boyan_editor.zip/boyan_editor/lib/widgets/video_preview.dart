import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';

class VideoPreview extends StatelessWidget {
  final VideoPlayerController? controller;
  final double projectRatio;

  const VideoPreview({super.key, required this.controller, required this.projectRatio});

  @override
  Widget build(BuildContext context) {
    final c = controller;
    return Center(
      child: AspectRatio(
        aspectRatio: projectRatio,
        child: Container(
          color: Colors.black,
          child: (c == null || !c.value.isInitialized)
              ? const Center(
                  child: Text('No video yet.\nTap "Media" to import one.',
                      textAlign: TextAlign.center))
              : Center(
                  child: AspectRatio(
                    aspectRatio: c.value.aspectRatio,
                    child: VideoPlayer(c),
                  ),
                ),
        ),
      ),
    );
  }
}
