import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:uuid/uuid.dart';
import '../core/utils/timeline_math.dart';
import '../models/timeline_clip.dart';

class TimelineState {
  final List<TimelineClip> clips;
  final String? selectedId;
  final bool canUndo;
  final bool canRedo;

  const TimelineState({
    this.clips = const [],
    this.selectedId,
    this.canUndo = false,
    this.canRedo = false,
  });

  TimelineClip? get selected {
    for (final c in clips) {
      if (c.id == selectedId) return c;
    }
    return null;
  }
}

final timelineProvider =
    NotifierProvider<TimelineNotifier, TimelineState>(TimelineNotifier.new);

class TimelineNotifier extends Notifier<TimelineState> {
  static const Duration minClip = Duration(milliseconds: 300);
  static const _uuid = Uuid();

  final List<List<TimelineClip>> _past = [];
  final List<List<TimelineClip>> _future = [];

  @override
  TimelineState build() => const TimelineState();

  /// Dipanggil saat editor dibuka. Mengosongkan riwayat undo/redo.
  void load(List<TimelineClip> clips) {
    _past.clear();
    _future.clear();
    state = TimelineState(clips: List.of(clips));
  }

  void select(String? id) {
    state = TimelineState(
      clips: state.clips,
      selectedId: id,
      canUndo: state.canUndo,
      canRedo: state.canRedo,
    );
  }

  void _commit(List<TimelineClip> next, {String? selectedId}) {
    _past.add(state.clips);
    if (_past.length > 50) _past.removeAt(0);
    _future.clear();
    state = TimelineState(
      clips: next,
      selectedId: selectedId,
      canUndo: true,
      canRedo: false,
    );
  }

  String? _keepSelection(List<TimelineClip> list) {
    final id = state.selectedId;
    return list.any((c) => c.id == id) ? id : null;
  }

  void addClip(TimelineClip clip) {
    _commit([...state.clips, clip], selectedId: clip.id);
  }

  /// Memotong klip di waktu timeline [t]. Mengembalikan false jika tidak bisa.
  bool splitAt(Duration t) {
    final clips = state.clips;
    final i = clipIndexAt(clips, t);
    if (i < 0) return false;
    final clip = clips[i];
    final offset = t - clipStarts(clips)[i];
    if (offset < minClip || clip.duration - offset < minClip) return false;
    final cut = clip.trimStart + offset;
    final a = clip.copyWith(trimEnd: cut);
    final b = clip.copyWith(id: _uuid.v4(), trimStart: cut);
    _commit(
      [...clips.sublist(0, i), a, b, ...clips.sublist(i + 1)],
      selectedId: b.id,
    );
    return true;
  }

  void deleteSelected() {
    final id = state.selectedId;
    if (id == null) return;
    _commit(state.clips.where((c) => c.id != id).toList(), selectedId: null);
  }

  void duplicateSelected() {
    final i = state.clips.indexWhere((c) => c.id == state.selectedId);
    if (i < 0) return;
    final copy = state.clips[i].copyWith(id: _uuid.v4());
    final next = [...state.clips]..insert(i + 1, copy);
    _commit(next, selectedId: copy.id);
  }

  void moveSelected(int delta) {
    final i = state.clips.indexWhere((c) => c.id == state.selectedId);
    final j = i + delta;
    if (i < 0 || j < 0 || j >= state.clips.length) return;
    final next = [...state.clips];
    final item = next.removeAt(i);
    next.insert(j, item);
    _commit(next, selectedId: item.id);
  }

  void setTrim(String id, Duration start, Duration end) {
    final i = state.clips.indexWhere((c) => c.id == id);
    if (i < 0) return;
    final clip = state.clips[i];
    if (start < Duration.zero ||
        end > clip.sourceDuration ||
        end - start < minClip) {
      return;
    }
    final next = [...state.clips];
    next[i] = clip.copyWith(trimStart: start, trimEnd: end);
    _commit(next, selectedId: id);
  }

  void undo() {
    if (_past.isEmpty) return;
    _future.add(state.clips);
    final prev = _past.removeLast();
    state = TimelineState(
      clips: prev,
      selectedId: _keepSelection(prev),
      canUndo: _past.isNotEmpty,
      canRedo: true,
    );
  }

  void redo() {
    if (_future.isEmpty) return;
    _past.add(state.clips);
    final next = _future.removeLast();
    state = TimelineState(
      clips: next,
      selectedId: _keepSelection(next),
      canUndo: true,
      canRedo: _future.isNotEmpty,
    );
  }
}
