import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:uuid/uuid.dart';
import '../core/services/project_storage.dart';
import '../models/project.dart';

final storageProvider = Provider<ProjectStorage>((ref) => ProjectStorage());

final projectsProvider =
    AsyncNotifierProvider<ProjectsNotifier, List<Project>>(ProjectsNotifier.new);

class ProjectsNotifier extends AsyncNotifier<List<Project>> {
  @override
  Future<List<Project>> build() => ref.read(storageProvider).loadAll();

  Future<Project> create({
    required String name,
    required String aspectRatio,
    required String resolution,
    required int fps,
  }) async {
    final now = DateTime.now();
    final project = Project(
      id: const Uuid().v4(),
      name: name,
      aspectRatio: aspectRatio,
      resolution: resolution,
      fps: fps,
      createdAt: now,
      updatedAt: now,
    );
    await ref.read(storageProvider).save(project);
    state = AsyncData(await ref.read(storageProvider).loadAll());
    return project;
  }

  Future<void> save(Project project) async {
    await ref.read(storageProvider).save(project);
    state = AsyncData(await ref.read(storageProvider).loadAll());
  }

  Future<void> rename(Project project, String newName) =>
      save(project.copyWith(name: newName, updatedAt: DateTime.now()));

  Future<void> remove(String id) async {
    await ref.read(storageProvider).delete(id);
    state = AsyncData(await ref.read(storageProvider).loadAll());
  }
}
