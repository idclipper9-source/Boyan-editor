import 'dart:convert';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import '../../models/project.dart';

/// Each project lives in: <app documents>/projects/<id>/
///   project.json  (metadata)
///   media/        (copied video files)
class ProjectStorage {
  Future<Directory> _root() async {
    final docs = await getApplicationDocumentsDirectory();
    final dir = Directory(p.join(docs.path, 'projects'));
    if (!await dir.exists()) await dir.create(recursive: true);
    return dir;
  }

  Future<Directory> _projectDir(String id) async {
    final dir = Directory(p.join((await _root()).path, id));
    if (!await dir.exists()) await dir.create(recursive: true);
    return dir;
  }

  Future<List<Project>> loadAll() async {
    final root = await _root();
    final projects = <Project>[];
    await for (final entity in root.list()) {
      if (entity is! Directory) continue;
      final file = File(p.join(entity.path, 'project.json'));
      if (!await file.exists()) continue;
      try {
        projects.add(Project.fromJson(jsonDecode(await file.readAsString())));
      } catch (e) {
        debugPrint('Failed to read project ${entity.path}: $e');
      }
    }
    projects.sort((a, b) => b.updatedAt.compareTo(a.updatedAt));
    return projects;
  }

  Future<void> save(Project project) async {
    final dir = await _projectDir(project.id);
    final tmp = File(p.join(dir.path, 'project.json.tmp'));
    await tmp.writeAsString(jsonEncode(project.toJson()));
    await tmp.rename(p.join(dir.path, 'project.json')); // safe write
  }

  Future<void> delete(String id) async {
    final dir = Directory(p.join((await _root()).path, id));
    if (await dir.exists()) await dir.delete(recursive: true);
  }

  /// Copies a picked file into the project folder so it survives cache cleanup.
  Future<String> importMedia(String projectId, String sourcePath) async {
    final dir = Directory(p.join((await _projectDir(projectId)).path, 'media'));
    if (!await dir.exists()) await dir.create(recursive: true);
    final name = '${DateTime.now().millisecondsSinceEpoch}${p.extension(sourcePath)}';
    final dest = p.join(dir.path, name);
    await File(sourcePath).copy(dest);
    return dest;
  }
}
