import '../../models/timeline_clip.dart';

Duration totalDuration(List<TimelineClip> clips) =>
    clips.fold(Duration.zero, (a, c) => a + c.duration);

/// Waktu mulai tiap klip di timeline (klip disusun berurutan).
List<Duration> clipStarts(List<TimelineClip> clips) {
  final out = <Duration>[];
  var acc = Duration.zero;
  for (final c in clips) {
    out.add(acc);
    acc += c.duration;
  }
  return out;
}

/// Index klip yang mencakup waktu [t]. Jika t di akhir, mengembalikan klip terakhir.
/// Mengembalikan -1 jika tidak ada klip.
int clipIndexAt(List<TimelineClip> clips, Duration t) {
  if (clips.isEmpty) return -1;
  var acc = Duration.zero;
  for (var i = 0; i < clips.length; i++) {
    final end = acc + clips[i].duration;
    if (t < end) return i;
    acc = end;
  }
  return clips.length - 1;
}

Duration clampDuration(Duration v, Duration lo, Duration hi) =>
    v < lo ? lo : (v > hi ? hi : v);
