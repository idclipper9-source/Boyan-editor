import 'package:uuid/uuid.dart';
import 'timeline_clip.dart';

class Project {
  final String id;
  final String name;
  final String aspectRatio; // contoh "9:16"
  final String resolution; // contoh "1080p"
  final int fps;
  final DateTime createdAt;
  final DateTime updatedAt;
  final List<TimelineClip> clips;
  final int durationMs;

  const Project({
    required this.id,
    required this.name,
    required this.aspectRatio,
    required this.resolution,
    required this.fps,
    required this.createdAt,
    required this.updatedAt,
    this.clips = const [],
    this.durationMs = 0,
  });

  double get ratio {
    final p = aspectRatio.split(':');
    final w = double.tryParse(p[0]) ?? 16;
    final h = double.tryParse(p[1]) ?? 9;
    return w / h;
  }

  Project copyWith({
    String? name,
    DateTime? updatedAt,
    List<TimelineClip>? clips,
    int? durationMs,
  }) {
    return Project(
      id: id,
      name: name ?? this.name,
      aspectRatio: aspectRatio,
      resolution: resolution,
      fps: fps,
      createdAt: createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      clips: clips ?? this.clips,
      durationMs: durationMs ?? this.durationMs,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'aspectRatio': aspectRatio,
        'resolution': resolution,
        'fps': fps,
        'createdAt': createdAt.toIso8601String(),
        'updatedAt': updatedAt.toIso8601String(),
        'clips': clips.map((c) => c.toJson()).toList(),
        'durationMs': durationMs,
      };

  factory Project.fromJson(Map<String, dynamic> j) {
    final ms = (j['durationMs'] as int?) ?? 0;
    List<TimelineClip> clips;
    if (j['clips'] != null) {
      clips = (j['clips'] as List)
          .map((e) => TimelineClip.fromJson(Map<String, dynamic>.from(e as Map)))
          .toList();
    } else {
      // Migrasi proyek Fase 1: satu video di "mediaPaths".
      final media = (j['mediaPaths'] as List?)?.cast<String>() ?? const <String>[];
      clips = [
        if (ms > 0)
          for (final path in media)
            TimelineClip(
              id: const Uuid().v4(),
              type: ClipType.video,
              source: path,
              sourceDuration: Duration(milliseconds: ms),
              trimStart: Duration.zero,
              trimEnd: Duration(milliseconds: ms),
            ),
      ];
    }
    return Project(
      id: j['id'] as String,
      name: j['name'] as String,
      aspectRatio: j['aspectRatio'] as String,
      resolution: j['resolution'] as String,
      fps: j['fps'] as int,
      createdAt: DateTime.parse(j['createdAt'] as String),
      updatedAt: DateTime.parse(j['updatedAt'] as String),
      clips: clips,
      durationMs: ms,
    );
  }
}
