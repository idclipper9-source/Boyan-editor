enum ClipType { video, image, audio, text }

class TimelineClip {
  final String id;
  final ClipType type;
  final String source; // path file di folder proyek
  final Duration sourceDuration; // panjang asli file
  final Duration trimStart; // posisi awal di dalam file sumber
  final Duration trimEnd; // posisi akhir di dalam file sumber
  final double speed; // disimpan, BELUM dipakai di Fase 2
  final double volume; // disimpan, BELUM dipakai di Fase 2

  const TimelineClip({
    required this.id,
    required this.type,
    required this.source,
    required this.sourceDuration,
    required this.trimStart,
    required this.trimEnd,
    this.speed = 1.0,
    this.volume = 1.0,
  });

  /// Panjang klip di timeline (waktu mulai dihitung dari urutan klip).
  Duration get duration => trimEnd - trimStart;

  TimelineClip copyWith({
    String? id,
    Duration? trimStart,
    Duration? trimEnd,
  }) {
    return TimelineClip(
      id: id ?? this.id,
      type: type,
      source: source,
      sourceDuration: sourceDuration,
      trimStart: trimStart ?? this.trimStart,
      trimEnd: trimEnd ?? this.trimEnd,
      speed: speed,
      volume: volume,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'type': type.name,
        'source': source,
        'sourceDurationMs': sourceDuration.inMilliseconds,
        'trimStartMs': trimStart.inMilliseconds,
        'trimEndMs': trimEnd.inMilliseconds,
        'speed': speed,
        'volume': volume,
      };

  factory TimelineClip.fromJson(Map<String, dynamic> j) => TimelineClip(
        id: j['id'] as String,
        type: ClipType.values.byName(j['type'] as String),
        source: j['source'] as String,
        sourceDuration: Duration(milliseconds: j['sourceDurationMs'] as int),
        trimStart: Duration(milliseconds: j['trimStartMs'] as int),
        trimEnd: Duration(milliseconds: j['trimEndMs'] as int),
        speed: (j['speed'] as num).toDouble(),
        volume: (j['volume'] as num).toDouble(),
      );
}
