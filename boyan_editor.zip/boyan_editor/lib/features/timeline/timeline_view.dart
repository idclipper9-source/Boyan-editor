import 'package:flutter/material.dart';
import '../../core/utils/format.dart';
import '../../models/timeline_clip.dart';

/// Timeline horizontal. Playhead ada di tengah layar; timeline yang bergeser.
class TimelineView extends StatelessWidget {
  final List<TimelineClip> clips;
  final String? selectedId;
  final double pixelsPerSecond;
  final ScrollController controller;
  final ValueChanged<String> onSelect;

  const TimelineView({
    super.key,
    required this.clips,
    required this.selectedId,
    required this.pixelsPerSecond,
    required this.controller,
    required this.onSelect,
  });

  @override
  Widget build(BuildContext context) {
    final accent = Theme.of(context).colorScheme.primary;

    return LayoutBuilder(builder: (context, box) {
      final half = box.maxWidth / 2;
      var totalSeconds = 0.0;
      for (final c in clips) {
        totalSeconds += c.duration.inMilliseconds / 1000;
      }
      final contentWidth = half * 2 + totalSeconds * pixelsPerSecond;

      return Stack(
        children: [
          SingleChildScrollView(
            controller: controller,
            scrollDirection: Axis.horizontal,
            physics: const ClampingScrollPhysics(),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                CustomPaint(
                  size: Size(contentWidth, 24),
                  painter: _RulerPainter(
                    padding: half,
                    pps: pixelsPerSecond,
                    totalSeconds: totalSeconds,
                  ),
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    SizedBox(width: half),
                    for (final clip in clips)
                      _ClipTile(
                        clip: clip,
                        width: clip.duration.inMilliseconds /
                            1000 *
                            pixelsPerSecond,
                        selected: clip.id == selectedId,
                        accent: accent,
                        onTap: () => onSelect(clip.id),
                      ),
                    SizedBox(width: half),
                  ],
                ),
              ],
            ),
          ),
          // Playhead tetap di tengah
          Positioned.fill(
            child: IgnorePointer(
              child: Center(
                child: Container(width: 2, color: Colors.white),
              ),
            ),
          ),
        ],
      );
    });
  }
}

class _ClipTile extends StatelessWidget {
  final TimelineClip clip;
  final double width;
  final bool selected;
  final Color accent;
  final VoidCallback onTap;

  const _ClipTile({
    required this.clip,
    required this.width,
    required this.selected,
    required this.accent,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: SizedBox(
        width: width,
        height: 64,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 1),
          child: DecoratedBox(
            decoration: BoxDecoration(
              color: selected ? accent.withAlpha(110) : const Color(0xFF2B2E3A),
              borderRadius: BorderRadius.circular(8),
              border: selected ? Border.all(color: Colors.white, width: 2) : null,
            ),
            child: ClipRect(
              child: Padding(
                padding: const EdgeInsets.all(6),
                child: Align(
                  alignment: Alignment.topLeft,
                  child: Text(
                    formatDuration(clip.duration),
                    maxLines: 1,
                    softWrap: false,
                    overflow: TextOverflow.clip,
                    style: const TextStyle(fontSize: 11),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _RulerPainter extends CustomPainter {
  final double padding;
  final double pps;
  final double totalSeconds;

  _RulerPainter({
    required this.padding,
    required this.pps,
    required this.totalSeconds,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = const Color(0x66FFFFFF)
      ..strokeWidth = 1;
    final minor = pps >= 30 ? 1 : 5;
    final major = minor == 1 ? 5 : 10;

    for (var s = 0; s <= totalSeconds.ceil(); s += minor) {
      final x = padding + s * pps;
      final isMajor = s % major == 0;
      canvas.drawLine(
        Offset(x, size.height),
        Offset(x, size.height - (isMajor ? 10 : 5)),
        paint,
      );
      if (isMajor) {
        final tp = TextPainter(
          text: TextSpan(
            text: formatDuration(Duration(seconds: s)),
            style: const TextStyle(fontSize: 10, color: Color(0x99FFFFFF)),
          ),
          textDirection: TextDirection.ltr,
        )..layout();
        tp.paint(canvas, Offset(x + 3, 0));
      }
    }
  }

  @override
  bool shouldRepaint(covariant _RulerPainter old) =>
      old.padding != padding || old.pps != pps || old.totalSeconds != totalSeconds;
}
