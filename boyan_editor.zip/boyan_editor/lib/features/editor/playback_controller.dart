import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:flutter/widgets.dart';
import 'package:video_player/video_player.dart';
import '../../core/utils/timeline_math.dart';
import '../../models/timeline_clip.dart';

class PlaybackController extends ChangeNotifier {
  List<TimelineClip> _clips = [];
  VideoPlayerController? _video;
  String? _source;
  int _tok = 0; // token: permintaan seek/load yang lebih baru membatalkan yang lama
  int _playIndex = 0;
  Duration _position = Duration.zero;
  bool _playing = false;
  bool _muted = false;
  bool _seeking = false;
  bool _advancing = false;
  bool _disposed = false;

  VideoPlayerController? get video => _video;
  Duration get position => _position;
  bool get isPlaying => _playing;
  bool get muted => _muted;
  Duration get total => totalDuration(_clips);

  void _notify() {
    if (!_disposed) notifyListeners();
  }

  /// Dipanggil setiap daftar klip berubah.
  Future<void> setClips(List<TimelineClip> clips) async {
    _clips = clips;
    if (_position > total) _position = total;
    await seek(_position);
  }

  /// Pindah ke waktu [t] di timeline.
  Future<void> seek(Duration t) async {
    final tok = ++_tok;
    _seeking = true;
    if (_clips.isEmpty) {
      _position = Duration.zero;
      _playing = false;
      _seeking = false;
      await _release();
      _notify();
      return;
    }
    final tt = clampDuration(t, Duration.zero, total);
    _position = tt;
    _notify();

    final i = clipIndexAt(_clips, tt);
    final clip = _clips[i];
    var offset = tt - clipStarts(_clips)[i];
    if (offset > clip.duration) offset = clip.duration;
    _playIndex = i;

    try {
      final ok = await _ensure(clip.source, tok);
      if (!ok || tok != _tok) return;
      final v = _video;
      if (v == null) return;
      await v.seekTo(clip.trimStart + offset);
      if (tok != _tok) return;
      if (_playing) await v.play();
    } catch (e) {
      debugPrint('Seek failed: $e');
    } finally {
      if (tok == _tok) _seeking = false;
    }
  }

  Future<void> play() async {
    if (_clips.isEmpty) return;
    if (_position >= total - const Duration(milliseconds: 50)) {
      _position = Duration.zero;
    }
    _playing = true;
    _notify();
    await seek(_position);
  }

  void pause() {
    _playing = false;
    _video?.pause();
    _notify();
  }

  Future<void> togglePlay() async {
    if (_playing) {
      pause();
    } else {
      await play();
    }
  }

  void setMuted(bool value) {
    _muted = value;
    _video?.setVolume(value ? 0 : 1);
    _notify();
  }

  // Memastikan controller untuk file [source] sudah aktif.
  Future<bool> _ensure(String source, int tok) async {
    if (_video != null && _source == source) return true;
    final c = VideoPlayerController.file(File(source));
    try {
      await c.initialize();
    } catch (e) {
      debugPrint('Video init failed: $e'); // detail teknis hanya di log
      await c.dispose();
      return false;
    }
    if (tok != _tok || _disposed) {
      await c.dispose();
      return false;
    }
    await c.setVolume(_muted ? 0 : 1);
    final old = _video;
    old?.removeListener(_onTick);
    c.addListener(_onTick);
    _video = c;
    _source = source;
    _notify();
    if (old != null) {
      // Dispose setelah frame berikutnya, agar widget lama tidak memakai controller yang sudah mati.
      WidgetsBinding.instance.addPostFrameCallback((_) => old.dispose());
      WidgetsBinding.instance.scheduleFrame();
    }
    return true;
  }

  Future<void> _release() async {
    final old = _video;
    old?.removeListener(_onTick);
    _video = null;
    _source = null;
    if (old != null) {
      WidgetsBinding.instance.addPostFrameCallback((_) => old.dispose());
      WidgetsBinding.instance.scheduleFrame();
    }
  }

  // Dipanggil setiap video_player memperbarui posisinya.
  void _onTick() {
    final v = _video;
    if (v == null || !_playing || _seeking || _advancing || _clips.isEmpty) return;
    if (_playIndex >= _clips.length || !v.value.isInitialized) return;
    final clip = _clips[_playIndex];
    final vp = v.value.position;
    if (vp >= clip.trimEnd - const Duration(milliseconds: 40)) {
      _advance();
      return;
    }
    final start = clipStarts(_clips)[_playIndex];
    var t = start + (vp - clip.trimStart);
    if (t < start) t = start;
    _position = t;
    _notify();
  }

  // Lanjut ke klip berikutnya saat klip sekarang selesai.
  Future<void> _advance() async {
    _advancing = true;
    try {
      final cur = _clips[_playIndex];
      final next = _playIndex + 1;
      if (next >= _clips.length) {
        _video?.pause();
        _playing = false;
        _position = total;
        _notify();
        return;
      }
      final nc = _clips[next];
      _playIndex = next;
      _position = clipStarts(_clips)[next];
      _notify();

      // Klip hasil split yang berurutan: video lanjut tanpa lompat.
      if (nc.source == cur.source && nc.trimStart == cur.trimEnd) return;

      final tok = ++_tok;
      _seeking = true;
      final ok = await _ensure(nc.source, tok);
      if (tok != _tok) return;
      if (!ok) {
        _playing = false;
        _seeking = false;
        _notify();
        return;
      }
      await _video!.seekTo(nc.trimStart);
      if (tok != _tok) return;
      await _video!.play();
      _seeking = false;
    } catch (e) {
      debugPrint('Advance failed: $e');
      _seeking = false;
    } finally {
      _advancing = false;
    }
  }

  @override
  void dispose() {
    _disposed = true;
    _video?.removeListener(_onTick);
    _video?.dispose();
    super.dispose();
  }
}
