import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:image_picker/image_picker.dart';
import 'package:uuid/uuid.dart';
import 'package:video_player/video_player.dart';
import '../../core/utils/format.dart';
import '../../core/utils/timeline_math.dart';
import '../../models/project.dart';
import '../../models/timeline_clip.dart';
import '../../providers/project_providers.dart';
import '../../providers/timeline_provider.dart';
import '../../widgets/editor_toolbar.dart';
import '../../widgets/video_preview.dart';
import '../timeline/timeline_view.dart';
import 'playback_controller.dart';

class EditorScreen extends ConsumerStatefulWidget {
  final Project project;
  const EditorScreen({super.key, required this.project});

  @override
  ConsumerState<EditorScreen> createState() => _EditorScreenState();
}

class _EditorScreenState extends ConsumerState<EditorScreen> {
  static const _uuid = Uuid();

  late Project _project;
  final PlaybackController _playback = PlaybackController();
  final ScrollController _scroll = ScrollController();

  double _pps = 50; // piksel per detik (zoom)
  bool _loaded = false;
  bool _userScrolling = false;
  bool _programmatic = false;
  bool _dirty = false;
  Timer? _saveTimer;
  String _saveStatus = 'Saved';

  @override
  void initState() {
    super.initState();
    _project = widget.project;
    _playback.addListener(_onPlayback);
    Future.microtask(_init);
  }

  Future<void> _init() async {
    ref.read(timelineProvider.notifier).load(_project.clips);
    await _playback.setClips(ref.read(timelineProvider).clips);
    if (!mounted) return;
    setState(() => _loaded = true);
  }

  @override
  void dispose() {
    _saveTimer?.cancel();
    _playback.removeListener(_onPlayback);
    _playback.dispose();
    _scroll.dispose();
    super.dispose();
  }

  void _msg(String text) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(text)));
  }

  // ---------- Sinkronisasi playback <-> timeline ----------

  void _onPlayback() {
    if (!mounted) return;
    setState(() {});
    if (!_userScrolling) _syncScroll();
  }

  void _syncScroll() {
    if (!_scroll.hasClients) return;
    final target = _playback.position.inMilliseconds / 1000 * _pps;
    final v = target.clamp(0.0, _scroll.position.maxScrollExtent);
    if ((v - _scroll.offset).abs() < 0.5) return;
    _programmatic = true;
    _scroll.jumpTo(v);
    _programmatic = false;
  }

  bool _onScroll(ScrollNotification n) {
    if (_programmatic) return false;
    if (n is ScrollStartNotification && n.dragDetails != null) {
      _userScrolling = true;
      if (_playback.isPlaying) _playback.pause();
    } else if (n is ScrollUpdateNotification && _userScrolling) {
      final ms = (n.metrics.pixels / _pps * 1000).round();
      _playback.seek(Duration(milliseconds: ms));
    } else if (n is ScrollEndNotification) {
      _userScrolling = false;
    }
    return false;
  }

  // ---------- Autosave ----------

  void _scheduleSave() {
    _dirty = true;
    _saveTimer?.cancel();
    setState(() => _saveStatus = 'Saving...');
    _saveTimer = Timer(const Duration(milliseconds: 700), _saveNow);
  }

  Future<void> _saveNow() async {
    _saveTimer?.cancel();
    if (!_dirty) return;
    _dirty = false;
    final clips = ref.read(timelineProvider).clips;
    _project = _project.copyWith(
      clips: clips,
      durationMs: totalDuration(clips).inMilliseconds,
      updatedAt: DateTime.now(),
    );
    try {
      await ref.read(projectsProvider.notifier).save(_project);
      if (mounted) setState(() => _saveStatus = 'Saved');
    } catch (e) {
      debugPrint('Save failed: $e');
      if (mounted) setState(() => _saveStatus = 'Not saved');
    }
  }

  // ---------- Aksi edit ----------

  void _afterEdit({bool toSelectedStart = false}) {
    final st = ref.read(timelineProvider);
    _playback.setClips(st.clips);
    if (toSelectedStart) {
      final i = st.clips.indexWhere((c) => c.id == st.selectedId);
      if (i >= 0) _playback.seek(clipStarts(st.clips)[i]);
    }
    _scheduleSave();
    WidgetsBinding.instance.addPostFrameCallback((_) => _syncScroll());
  }

  VoidCallback _needSelection(VoidCallback action) => () {
        if (ref.read(timelineProvider).selected == null) {
          _msg('Tap a clip in the timeline first.');
          return;
        }
        action();
      };

  Future<void> _importVideo() async {
    final picked = await ImagePicker().pickVideo(source: ImageSource.gallery);
    if (picked == null) return;
    _playback.pause();
    setState(() => _saveStatus = 'Importing...');
    try {
      final path =
          await ref.read(storageProvider).importMedia(_project.id, picked.path);
      final probe = VideoPlayerController.file(File(path));
      await probe.initialize();
      final dur = probe.value.duration;
      await probe.dispose();

      final start = totalDuration(ref.read(timelineProvider).clips);
      ref.read(timelineProvider.notifier).addClip(TimelineClip(
            id: _uuid.v4(),
            type: ClipType.video,
            source: path,
            sourceDuration: dur,
            trimStart: Duration.zero,
            trimEnd: dur,
          ));
      _afterEdit();
      _playback.seek(start);
    } catch (e) {
      debugPrint('Import failed: $e');
      if (mounted) setState(() => _saveStatus = 'Saved');
      _msg('Unable to import this video. Please try again.');
    }
  }

  void _split() {
    _playback.pause();
    final ok = ref.read(timelineProvider.notifier).splitAt(_playback.position);
    if (!ok) {
      _msg('Move the playhead inside a clip to split it.');
      return;
    }
    _afterEdit();
  }

  void _delete() {
    _playback.pause();
    ref.read(timelineProvider.notifier).deleteSelected();
    _afterEdit();
  }

  void _duplicate() {
    _playback.pause();
    ref.read(timelineProvider.notifier).duplicateSelected();
    _afterEdit(toSelectedStart: true);
  }

  void _move(int delta) {
    _playback.pause();
    ref.read(timelineProvider.notifier).moveSelected(delta);
    _afterEdit(toSelectedStart: true);
  }

  void _undo() {
    _playback.pause();
    ref.read(timelineProvider.notifier).undo();
    _afterEdit();
  }

  void _redo() {
    _playback.pause();
    ref.read(timelineProvider.notifier).redo();
    _afterEdit();
  }

  void _zoom(double factor) {
    setState(() => _pps = (_pps * factor).clamp(15.0, 200.0));
    WidgetsBinding.instance.addPostFrameCallback((_) => _syncScroll());
  }

  void _trim() {
    final clip = ref.read(timelineProvider).selected;
    if (clip == null) return;
    _playback.pause();
    var range = RangeValues(
      clip.trimStart.inMilliseconds.toDouble(),
      clip.trimEnd.inMilliseconds.toDouble(),
    );
    String sec(double ms) => '${(ms / 1000).toStringAsFixed(1)}s';

    showModalBottomSheet(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setLocal) => Padding(
          padding: const EdgeInsets.fromLTRB(20, 20, 20, 28),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text('Trim clip',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
              const SizedBox(height: 12),
              RangeSlider(
                values: range,
                min: 0,
                max: clip.sourceDuration.inMilliseconds.toDouble(),
                onChanged: (v) {
                  if (v.end - v.start < 300) return;
                  setLocal(() => range = v);
                },
                onChangeEnd: (v) {
                  if (v.end - v.start < 300) return;
                  ref.read(timelineProvider.notifier).setTrim(
                        clip.id,
                        Duration(milliseconds: v.start.round()),
                        Duration(milliseconds: v.end.round()),
                      );
                  _afterEdit(toSelectedStart: true);
                },
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text('Start ${sec(range.start)}'),
                  Text('Length ${sec(range.end - range.start)}'),
                  Text('End ${sec(range.end)}'),
                ],
              ),
              const SizedBox(height: 16),
              SizedBox(
                width: double.infinity,
                child: FilledButton(
                  onPressed: () => Navigator.pop(ctx),
                  child: const Text('Done'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _soon() => _msg('Coming in a later phase.');

  // ---------- UI ----------

  @override
  Widget build(BuildContext context) {
    final tl = ref.watch(timelineProvider);
    final hasSel = tl.selected != null;
    final hasClips = tl.clips.isNotEmpty;

    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, _) async {
        if (didPop) return;
        _playback.pause();
        await _saveNow();
        if (mounted) Navigator.of(context).pop();
      },
      child: Scaffold(
        appBar: AppBar(
          title: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(_project.name, style: const TextStyle(fontSize: 16)),
              Text(_saveStatus,
                  style: const TextStyle(fontSize: 11, color: Colors.white54)),
            ],
          ),
          actions: [
            IconButton(
              icon: const Icon(Icons.undo),
              onPressed: tl.canUndo ? _undo : null,
            ),
            IconButton(
              icon: const Icon(Icons.redo),
              onPressed: tl.canRedo ? _redo : null,
            ),
            TextButton(onPressed: _soon, child: const Text('Export')),
          ],
        ),
        body: SafeArea(
          child: !_loaded
              ? const Center(child: CircularProgressIndicator())
              : Column(
                  children: [
                    Expanded(
                      child: VideoPreview(
                        controller: _playback.video,
                        projectRatio: _project.ratio,
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 8),
                      child: Row(
                        children: [
                          IconButton(
                            iconSize: 34,
                            icon: Icon(_playback.isPlaying
                                ? Icons.pause_circle
                                : Icons.play_circle),
                            onPressed: hasClips ? _playback.togglePlay : null,
                          ),
                          Text(
                            '${formatDuration(_playback.position)} / '
                            '${formatDuration(_playback.total)}',
                            style: const TextStyle(fontSize: 12),
                          ),
                          const Spacer(),
                          IconButton(
                            icon: const Icon(Icons.zoom_out),
                            onPressed: () => _zoom(0.7),
                          ),
                          IconButton(
                            icon: const Icon(Icons.zoom_in),
                            onPressed: () => _zoom(1.4),
                          ),
                          IconButton(
                            icon: Icon(_playback.muted
                                ? Icons.volume_off
                                : Icons.volume_up),
                            onPressed: () => _playback.setMuted(!_playback.muted),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(
                      height: 104,
                      child: hasClips
                          ? NotificationListener<ScrollNotification>(
                              onNotification: _onScroll,
                              child: TimelineView(
                                clips: tl.clips,
                                selectedId: tl.selectedId,
                                pixelsPerSecond: _pps,
                                controller: _scroll,
                                onSelect: (id) => ref
                                    .read(timelineProvider.notifier)
                                    .select(id == tl.selectedId ? null : id),
                              ),
                            )
                          : const Center(
                              child: Text('Tap "Media" to add your first video.',
                                  style: TextStyle(color: Colors.white54)),
                            ),
                    ),
                    const Divider(height: 1),
                    EditorToolbar(items: [
                      ToolItem('Media', Icons.video_library_outlined, _importVideo,
                          enabled: true),
                      ToolItem('Split', Icons.content_cut, _split,
                          enabled: hasClips),
                      ToolItem('Trim', Icons.crop, _needSelection(_trim),
                          enabled: hasSel),
                      ToolItem('Duplicate', Icons.copy, _needSelection(_duplicate),
                          enabled: hasSel),
                      ToolItem('Move ◀', Icons.arrow_back,
                          _needSelection(() => _move(-1)),
                          enabled: hasSel),
                      ToolItem('Move ▶', Icons.arrow_forward,
                          _needSelection(() => _move(1)),
                          enabled: hasSel),
                      ToolItem('Delete', Icons.delete_outline,
                          _needSelection(_delete),
                          enabled: hasSel),
                      ToolItem('Text', Icons.title, _soon),
                      ToolItem('Audio', Icons.music_note_outlined, _soon),
                      ToolItem('Voice', Icons.mic_none, _soon),
                      ToolItem('Caption', Icons.subtitles_outlined, _soon),
                      ToolItem('Effects', Icons.auto_awesome_outlined, _soon),
                      ToolItem('Speed', Icons.speed, _soon),
                      ToolItem('AI', Icons.smart_toy_outlined, _soon),
                    ]),
                  ],
                ),
        ),
      ),
    );
  }
}
