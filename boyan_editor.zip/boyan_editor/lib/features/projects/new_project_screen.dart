import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../providers/project_providers.dart';
import '../../widgets/app_button.dart';
import '../editor/editor_screen.dart';

class NewProjectScreen extends ConsumerStatefulWidget {
  const NewProjectScreen({super.key});

  @override
  ConsumerState<NewProjectScreen> createState() => _NewProjectScreenState();
}

class _NewProjectScreenState extends ConsumerState<NewProjectScreen> {
  final _name = TextEditingController(text: 'My Project');
  String _aspect = '9:16';
  String _resolution = '1080p';
  int _fps = 30;

  @override
  void dispose() {
    _name.dispose();
    super.dispose();
  }

  Widget _chips<T>(List<T> options, T selected, void Function(T) onSelect,
      {String Function(T)? label}) {
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: [
        for (final o in options)
          ChoiceChip(
            label: Text(label != null ? label(o) : '$o'),
            selected: o == selected,
            onSelected: (_) => setState(() => onSelect(o)),
          ),
      ],
    );
  }

  Widget _title(String t) => Padding(
        padding: const EdgeInsets.only(top: 20, bottom: 8),
        child: Text(t, style: const TextStyle(fontWeight: FontWeight.w600)),
      );

  Future<void> _create() async {
    final name = _name.text.trim().isEmpty ? 'Untitled' : _name.text.trim();
    final project = await ref.read(projectsProvider.notifier).create(
          name: name,
          aspectRatio: _aspect,
          resolution: _resolution,
          fps: _fps,
        );
    if (!mounted) return;
    Navigator.pushReplacement(
        context, MaterialPageRoute(builder: (_) => EditorScreen(project: project)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Create Project')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            _title('Project name'),
            TextField(controller: _name),
            _title('Aspect ratio'),
            _chips<String>(['9:16', '16:9', '1:1', '4:5'], _aspect,
                (v) => _aspect = v),
            const SizedBox(height: 6),
            const Text('Custom ratio: coming in a later phase.',
                style: TextStyle(fontSize: 12, color: Colors.white54)),
            _title('Resolution'),
            _chips<String>(['720p', '1080p', '1440p', '4K'], _resolution,
                (v) => _resolution = v),
            const SizedBox(height: 6),
            const Text('Saved as a setting now. Applied when export is built.',
                style: TextStyle(fontSize: 12, color: Colors.white54)),
            _title('Frame rate'),
            _chips<int>([24, 25, 30, 60], _fps, (v) => _fps = v,
                label: (v) => '$v FPS'),
            const SizedBox(height: 32),
            AppButton(label: 'Create Project', icon: Icons.check, onPressed: _create),
          ],
        ),
      ),
    );
  }
}
