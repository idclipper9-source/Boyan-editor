# Boyan Editor

Editor video Android berbasis Flutter (Fase 1 + Fase 2).

- Fase 1: proyek, penyimpanan lokal, import video, preview.
- Fase 2: timeline multi-klip, trim, split, duplikat, geser, hapus, undo/redo, autosave.

Folder `android/` dibuat otomatis oleh GitHub Actions saat build
(lihat `.github/workflows/build.yml`), jadi tidak perlu ada di repo.

Build APK: tab Actions > Build APK > Run workflow, lalu unduh artifact `boyan-editor-apk`.
