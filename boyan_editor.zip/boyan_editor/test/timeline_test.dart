import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:boyan_editor/core/utils/timeline_math.dart';
import 'package:boyan_editor/models/project.dart';
import 'package:boyan_editor/models/timeline_clip.dart';
import 'package:boyan_editor/providers/timeline_provider.dart';

TimelineClip makeClip(String id, int ms) => TimelineClip(
      id: id,
      type: ClipType.video,
      source: '/tmp/$id.mp4',
      sourceDuration: Duration(milliseconds: ms),
      trimStart: Duration.zero,
      trimEnd: Duration(milliseconds: ms),
    );

void main() {
  test('split, delete, undo, redo', () {
    final c = ProviderContainer();
    addTearDown(c.dispose);
    final n = c.read(timelineProvider.notifier);
    n.load([makeClip('a', 10000)]);

    expect(n.splitAt(const Duration(seconds: 4)), true);
    var s = c.read(timelineProvider);
    expect(s.clips.length, 2);
    expect(s.clips[0].duration, const Duration(seconds: 4));
    expect(s.clips[1].duration, const Duration(seconds: 6));
    expect(totalDuration(s.clips), const Duration(seconds: 10));

    // terlalu dekat tepi klip -> ditolak
    expect(n.splitAt(const Duration(milliseconds: 100)), false);

    n.deleteSelected(); // klip kedua terpilih setelah split
    s = c.read(timelineProvider);
    expect(s.clips.length, 1);

    n.undo();
    expect(c.read(timelineProvider).clips.length, 2);
    n.redo();
    expect(c.read(timelineProvider).clips.length, 1);
  });

  test('move, duplicate, trim', () {
    final c = ProviderContainer();
    addTearDown(c.dispose);
    final n = c.read(timelineProvider.notifier);
    n.load([makeClip('a', 10000), makeClip('b', 5000)]);

    n.select('a');
    n.moveSelected(1);
    expect(c.read(timelineProvider).clips.map((e) => e.id).toList(), ['b', 'a']);

    n.duplicateSelected();
    expect(c.read(timelineProvider).clips.length, 3);

    n.setTrim('b', const Duration(seconds: 1), const Duration(seconds: 3));
    expect(c.read(timelineProvider).clips[0].duration, const Duration(seconds: 2));

    // trim di luar panjang sumber -> diabaikan
    n.setTrim('b', Duration.zero, const Duration(seconds: 99));
    expect(c.read(timelineProvider).clips[0].duration, const Duration(seconds: 2));
  });

  test('migrasi proyek Fase 1', () {
    final p = Project.fromJson({
      'id': 'x',
      'name': 'Lama',
      'aspectRatio': '9:16',
      'resolution': '1080p',
      'fps': 30,
      'createdAt': '2026-01-01T00:00:00.000',
      'updatedAt': '2026-01-01T00:00:00.000',
      'mediaPaths': ['/tmp/v.mp4'],
      'durationMs': 5000,
    });
    expect(p.clips.length, 1);
    expect(p.clips.first.duration, const Duration(seconds: 5));
  });
}
